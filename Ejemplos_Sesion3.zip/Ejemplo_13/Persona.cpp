#include "Persona.hpp"

void Persona::getEdad()`{
	
}

