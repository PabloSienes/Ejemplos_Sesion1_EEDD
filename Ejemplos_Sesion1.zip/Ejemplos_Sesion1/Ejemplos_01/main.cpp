#include <stdio.h>

int main(int argc, char **argv)
{
	int x;
	std::cout << "Escriba un numero: ";
	std::cin >> x;
	std::cout << "El numero introducido es: " << x << "\n";
	
	return 0;
}
